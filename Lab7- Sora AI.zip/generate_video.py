import json
import os
import time
from pathlib import Path
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT", "").rstrip("/")
API_KEY = os.getenv("AZURE_OPENAI_API_KEY", "")
DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "") 

OUTPUT_DIR = Path("output")

def save_status(data, file_path):
    """Helper to save the current job status to a specific JSON file."""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    file_path.write_text(
        json.dumps(data, indent=2),
        encoding="utf-8",
    )

def main():
    if not all([ENDPOINT, API_KEY, DEPLOYMENT]):
        raise ValueError(
            "Check .env: AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, and "
            "AZURE_OPENAI_DEPLOYMENT_NAME are required."
        )

    prompt = input("Enter your Sora 2 video prompt: ").strip()
    if not prompt:
        raise ValueError("Prompt cannot be empty.")

    # Generate unique filenames using the current date and time
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    status_file = OUTPUT_DIR / f"status_{timestamp}.json"
    video_file = OUTPUT_DIR / f"video_{timestamp}.mp4"

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    client = OpenAI(
        base_url=f"{ENDPOINT}/openai/v1/",
        api_key=API_KEY,
    )

    result = {
        "model": DEPLOYMENT,
        "prompt": prompt,
        "status": "submitting",
    }
    save_status(result, status_file)

    try:
        print("\nSubmitting video-generation request...")
        
        video_response = client.videos.create(
            model=DEPLOYMENT,
            prompt=prompt
        )
        
        video_id = video_response.id
        result["video_id"] = video_id
        save_status(result, status_file)
        
        print(f"Job started with ID: {video_id}")
        print("Waiting for generation to complete (this may take several minutes)...")
        
        while True:
            job = client.videos.retrieve(video_id)
            status = job.status
            progress = getattr(job, "progress", "N/A")
            
            result["status"] = status
            result["progress"] = progress
            save_status(result, status_file)
            
            print(f"Status: {status} | Progress: {progress}")
            
            if status == "completed":
                break
            elif status in ["failed", "cancelled"]:
                error_msg = getattr(job, "error", "Unknown error")
                raise RuntimeError(f"Video generation did not complete successfully: {error_msg}")
            
            time.sleep(10)
        
        print("\nGeneration complete. Downloading video...")
        
        response = client.videos.download_content(video_id)
        video_bytes = response.read()
        
        with open(video_file, "wb") as f:
            f.write(video_bytes)

        result["output_file"] = str(video_file)
        result["file_size_bytes"] = video_file.stat().st_size
        result["status"] = "completed"
        save_status(result, status_file)

        print(f"Video successfully saved: {video_file}")
        print(f"Metadata saved: {status_file}")

    except Exception as exc:
        result["status"] = "error"
        result["error"] = str(exc)
        save_status(result, status_file)
        print(f"\nAPI request failed: {exc}")
        raise

if __name__ == "__main__":
    main()